package com.example.archermind.intentservicedemo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements MyIntentService.UpdateUI {
    private static int index = 0;

    /**
     * 图片地址集合
     */
    private String url[] = {
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1557206502889&di=d8c2e07e5bf741ecf41e8791a56659e7&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201610%2F19%2F20161019141713_cunTt.thumb.700_0.png",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1557206525998&di=b931db9e74d793b981439df25eb454b0&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201701%2F17%2F20170117110536_jCxYS.jpeg",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1557206535433&di=0c76cfa2ab93cc7c663349684768239e&imgtype=0&src=http%3A%2F%2Fimage.biaobaiju.com%2Fuploads%2F20181025%2F20%2F1540470601-bYokwErXve.jpg",
            "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2631873990,1771700737&fm=26&gp=0.jpg",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1557206623141&di=ea5832a007d3d748fa465786d5a0a4c9&imgtype=0&src=http%3A%2F%2Fgss0.baidu.com%2F9fo3dSag_xI4khGko9WTAnF6hhy%2Fzhidao%2Fpic%2Fitem%2Fb3119313b07eca801fdcebe7972397dda04483d1.jpg",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1557206703342&di=d1378ef6268cbb49776dcfa411baf415&imgtype=0&src=http%3A%2F%2Fp0.ifengimg.com%2Fpmop%2F2018%2F0917%2F99BDA2F430BFD89E1D51B872A050F35710FC6330_size12_w402_h321.jpeg"
    };

    private static ImageView imageView;
    @SuppressLint("HandlerLeak")
    private static final Handler mUIHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            imageView.setImageBitmap((Bitmap) msg.obj);
        }
    };

    private static final Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            imageView.setImageBitmap((Bitmap) msg.obj);
            return true;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = findViewById(R.id.image);
        Intent intent = new Intent(this,MyIntentService.class);

                for (int i = 0;i < 6 ; i++) {//循环启动任务
                    intent.putExtra(MyIntentService.DOWNLOAD_URL, url[i]);
                    intent.putExtra(MyIntentService.INDEX_FLAG, i);
                    startService(intent);//多次开启服务
                    MyIntentService.setUpdateUI(MainActivity.this);//使用接口回调 从MyIntentService 返回数据
                }



    }



    /**
     * 必须通过Handler去更新，该方法为异步，不可更新UI
     * @param message
     */
    @Override
    public void updateUI(Message message) {
//        mUIHandler.sendMessageDelayed(message,message.what *1000);
        mHandler.sendMessageDelayed(message,message.what *1000);
    }
}
