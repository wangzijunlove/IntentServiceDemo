package com.example.archermind.intentservicedemo;

import android.app.IntentService;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Message;
import android.support.annotation.Nullable;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by archermind on 5/7/19.
 * Wzj
 * content
 */

public class MyIntentService extends IntentService {
    public static final String DOWNLOAD_URL = "download_url";
    public static final String INDEX_FLAG  = "index_flag";
    public static UpdateUI updateUI;

    //定义一个更新UI的接口
    public interface UpdateUI{
        void updateUI(Message message);
    }

    public static void setUpdateUI(UpdateUI updateUIInterface){
        updateUI = updateUIInterface;
    }

    public MyIntentService() {
        super("MyIntentService");
    }

    /**
     * 实现异步任务的方法
     * @param intent Activity传递过来的Intent，数据封装在intent中
     */
    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        //在子线程中进行网络请求
        Bitmap bitmap = downloadUrlBitmap(intent.getStringExtra(DOWNLOAD_URL));
        Message message1 = new Message();
        message1.what = intent.getIntExtra(INDEX_FLAG,0);
        message1.obj = bitmap;
        //通知主线程去更新UI
        if(updateUI != null){
            updateUI.updateUI(message1);
        }
    }

    private Bitmap downloadUrlBitmap(String urlString){
        HttpURLConnection urlConnection = null;
        BufferedInputStream inputStream = null;
        Bitmap bitmap = null;

        try {
            final URL url = new URL(urlString);
            urlConnection = (HttpURLConnection) url.openConnection();
            inputStream = new BufferedInputStream(urlConnection.getInputStream(),8*1024);
            bitmap = BitmapFactory.decodeStream(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(urlConnection != null){
                urlConnection.disconnect();
            }
                try {
                    if(inputStream != null) {
                        inputStream.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return bitmap;
    }
}
