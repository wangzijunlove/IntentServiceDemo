package com.example.archermind.intentservicedemo1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    public final static String ACTION_TYPE_THREAD = "action.type.thread";
    private LocalBroadcastManager mLocalBroadcastManger;
    private MyBroadcastReceiver myBroadcastReceiver;

    private TextView tvStatus,tvSize;
    private Button mBtn;
    private ProgressBar mProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvStatus = findViewById(R.id.tv_status);
        tvSize = findViewById(R.id.tv_size);
        mBtn = findViewById(R.id.btn_start);
        mBtn.setOnClickListener(this);
        mProgress = findViewById(R.id.progress);

        //注册广播
        mLocalBroadcastManger = LocalBroadcastManager.getInstance(this);
        myBroadcastReceiver = new MyBroadcastReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ACTION_TYPE_THREAD);
        mLocalBroadcastManger.registerReceiver(myBroadcastReceiver,intentFilter);

        initView();
    }

    public void initView(){
        tvStatus.setText("线程状态：未运行");
        mProgress.setMax(100);
        mProgress.setProgress(0);
        tvSize.setText("0%");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_start:
                mBtn.setText("进行中");
                Intent intent = new Intent(MainActivity.this,MyIntentService.class);
                startService(intent);
                break;
        }
    }


    public class MyBroadcastReceiver extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()){
                case ACTION_TYPE_THREAD:
                    //更改UI
                    int progress = intent.getIntExtra("progress",0);
                    tvStatus.setText("线程状态：" + intent.getStringExtra("status"));
                    mProgress.setProgress(progress);
                    tvSize.setText(progress + "%");
                    if (progress >= 100) {
                        tvStatus.setText("线程结束");
                        mBtn.setText("开始");
                    }
                    break;
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //注销广播
        mLocalBroadcastManger.unregisterReceiver(myBroadcastReceiver);
    }
}
