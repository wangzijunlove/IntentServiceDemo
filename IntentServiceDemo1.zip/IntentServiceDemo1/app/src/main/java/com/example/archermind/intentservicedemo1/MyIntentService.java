package com.example.archermind.intentservicedemo1;

import android.app.IntentService;
import android.content.Intent;
import android.content.Context;
import android.content.res.Resources;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

public class MyIntentService extends IntentService {

    //是否正在运行
    private boolean isRunning;

    //进度
    private int count;

    //广播
    private LocalBroadcastManager broadcastManager;

    public MyIntentService() {
        super("MyIntentService");
        Log.e("MyIntentService class", "MyIntentService: ");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e("MyIntentService class", "onCreate: ");
        broadcastManager = LocalBroadcastManager.getInstance(this);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Log.e("MyIntentService class", "onHandleIntent: ");

        try {
            Thread.sleep(150);
            isRunning = true;
            count = 0;
            while (isRunning){
                count++;
                if(count >= 100){
                    isRunning = false;
                }
                Thread.sleep(50);
                sendThreadStatus("线程运行中",count);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 发送进度消息
     * @param status
     * @param progress
     */
    private void sendThreadStatus(String status, int progress){
        Intent intent = new Intent(MainActivity.ACTION_TYPE_THREAD);
        intent.putExtra("status",status);
        intent.putExtra("progress",progress);
        broadcastManager.sendBroadcast(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("MyIntentService class", "线程结束运行..." + count);
    }
}
